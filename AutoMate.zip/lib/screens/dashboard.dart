import 'dart:html' as html;
import 'package:flutter/material.dart';
import 'auto_reply_settings.dart';
import 'auto_scroll_settings.dart';
import 'simulation_mode.dart';
import 'security_settings.dart';
import 'drive_simulator.dart';
import 'control_panel.dart';
import 'timer_settings.dart';
// Phase 5 imports
import 'branding_settings.dart';
import 'editing_settings.dart';
import 'posting_queue.dart';
// Phase 6 imports
import 'human_behavior_settings.dart';
import 'comment_templates.dart';
// Phase 7 imports
import 'jarvis_dashboard.dart';
import 'daily_poster.dart';
import 'client_hunter.dart';

class Dashboard extends StatefulWidget {
  const Dashboard({super.key});

  @override
  State<Dashboard> createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  int phase = 1;

  @override
  void initState() {
    super.initState();
    _loadPhase();
  }

  void _loadPhase() {
    final stored = html.window.localStorage['currentPhase'];
    if (stored != null) {
      phase = int.tryParse(stored) ?? 1;
    }
  }

  void _savePhase(int newPhase) {
    html.window.localStorage['currentPhase'] = newPhase.toString();
    setState(() {
      phase = newPhase;
    });
  }

  void _nextPhase() {
    if (phase < 7) {
      _savePhase(phase + 1);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
            content: Text('Phase ${phase + 1} unlocked! New features added.')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('AutoMate - Phase $phase'),
        actions: [
          if (phase < 7)
            TextButton.icon(
              onPressed: _nextPhase,
              icon: const Icon(Icons.arrow_forward),
              label: const Text('Next'),
            ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // ========== PHASE 1 FEATURES ==========
          Card(
            child: ListTile(
              leading: const Icon(Icons.reply),
              title: const Text('Auto-Reply Settings'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const AutoReplySettings())),
            ),
          ),
          Card(
            child: ListTile(
              leading: const Icon(Icons.swap_vert),
              title: const Text('Auto Scroll Settings'),
              onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                      builder: (_) => const AutoScrollSettings())),
            ),
          ),

          // ========== PHASE 2 FEATURE ==========
          if (phase >= 2)
            Card(
              color: Colors.blue.shade900,
              child: ListTile(
                leading: const Icon(Icons.security, color: Colors.white),
                title: const Text('Security Settings',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Encryption, delete data',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const SecuritySettings())),
              ),
            ),

          // ========== PHASE 3 FEATURES ==========
          if (phase >= 3) ...[
            Card(
              color: Colors.green.shade900,
              child: ListTile(
                leading: const Icon(Icons.dashboard, color: Colors.white),
                title: const Text('Control Panel',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Auto/Manual mode, real-time stats',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ControlPanel())),
              ),
            ),
            Card(
              color: Colors.orange.shade900,
              child: ListTile(
                leading: const Icon(Icons.cloud, color: Colors.white),
                title: const Text('Google Drive Simulator',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Manage content, no-repeat system',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const DriveSimulator())),
              ),
            ),
          ],

          // ========== PHASE 4 FEATURE ==========
          if (phase >= 4)
            Card(
              color: Colors.purple.shade900,
              child: ListTile(
                leading: const Icon(Icons.timer, color: Colors.white),
                title: const Text('Timer & Schedule Settings',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text(
                    'Set timers for Instagram/WhatsApp, daily schedule',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const TimerSettings())),
              ),
            ),

          // ========== PHASE 5 FEATURES ==========
          if (phase >= 5) ...[
            Card(
              color: Colors.teal.shade900,
              child: ListTile(
                leading:
                    const Icon(Icons.branding_watermark, color: Colors.white),
                title: const Text('Auto Branding',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Username overlay, hide old logo',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const BrandingSettings())),
              ),
            ),
            Card(
              color: Colors.indigo.shade900,
              child: ListTile(
                leading: const Icon(Icons.edit, color: Colors.white),
                title: const Text('Content Editing',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Story format, background blur',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const EditingSettings())),
              ),
            ),
            Card(
              color: Colors.deepOrange.shade900,
              child: ListTile(
                leading: const Icon(Icons.queue, color: Colors.white),
                title: const Text('Posting Queue',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Sequential order, auto-post simulation',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const PostingQueue())),
              ),
            ),
          ],

          // ========== PHASE 6 FEATURES ==========
          if (phase >= 6) ...[
            Card(
              color: Colors.pink.shade900,
              child: ListTile(
                leading: const Icon(Icons.psychology, color: Colors.white),
                title: const Text('Human Behavior AI',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Random delays, actions, session limits',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const HumanBehaviorSettings())),
              ),
            ),
            Card(
              color: Colors.cyan.shade900,
              child: ListTile(
                leading: const Icon(Icons.comment, color: Colors.white),
                title: const Text('Comment Templates',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Manage AI-generated comments',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                        builder: (_) => const CommentTemplates())),
              ),
            ),
          ],

          // ========== PHASE 7 FEATURES (FULL JARVIS MODE) ==========
          if (phase >= 7) ...[
            Card(
              color: Colors.black87,
              child: ListTile(
                leading: const Icon(Icons.android, color: Colors.white),
                title: const Text('🤖 JARVIS Mode - Full System',
                    style: TextStyle(
                        color: Colors.white, fontWeight: FontWeight.bold)),
                subtitle: const Text(
                    'Complete AI automation: Drive + Post + Engage',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const JarvisDashboard())),
              ),
            ),
            Card(
              color: Colors.brown.shade900,
              child: ListTile(
                leading: const Icon(Icons.calendar_today, color: Colors.white),
                title: const Text('Daily Post & Story Scheduler',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text(
                    'Schedule posts/stories, auto content from Drive',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const DailyPoster())),
              ),
            ),
            Card(
              color: Colors.deepPurple.shade900,
              child: ListTile(
                leading: const Icon(Icons.track_changes, color: Colors.white),
                title: const Text('Client Hunting System',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Find leads based on keywords (simulated)',
                    style: TextStyle(color: Colors.white70)),
                onTap: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const ClientHunter())),
              ),
            ),
          ],

          // ========== SIMULATION MODE (always available) ==========
          Card(
            child: ListTile(
              leading: const Icon(Icons.sim_card),
              title: const Text('Simulation Mode (Test)'),
              onTap: () => Navigator.push(context,
                  MaterialPageRoute(builder: (_) => const SimulationMode())),
            ),
          ),
        ],
      ),
    );
  }
}
