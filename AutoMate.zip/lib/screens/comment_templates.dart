import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';

class CommentTemplates extends StatefulWidget {
  const CommentTemplates({super.key});

  @override
  State<CommentTemplates> createState() => _CommentTemplatesState();
}

class _CommentTemplatesState extends State<CommentTemplates> {
  List<String> templates = [];

  @override
  void initState() {
    super.initState();
    _loadTemplates();
  }

  void _loadTemplates() {
    final stored = html.window.localStorage['commentTemplates'];
    if (stored != null) {
      templates = List<String>.from(jsonDecode(stored));
    } else {
      templates = [
        "Great post! 🔥",
        "Very informative, thanks for sharing!",
        "Love this content! 🙌",
        "Exactly what I needed to see today.",
        "This is so useful, keep it up!",
        "Amazing work 👏",
        "I totally agree with you.",
        "Thanks for the value! 💯"
      ];
      _saveTemplates();
    }
  }

  void _saveTemplates() {
    html.window.localStorage['commentTemplates'] = jsonEncode(templates);
  }

  void _addTemplate(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      templates.add(text.trim());
    });
    _saveTemplates();
  }

  void _removeTemplate(int index) {
    setState(() {
      templates.removeAt(index);
    });
    _saveTemplates();
  }

  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('AI Comment Templates')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            const Text('These comments will be randomly selected when engaging',
                style: TextStyle(fontSize: 12)),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: templates.length,
                itemBuilder: (ctx, i) => ListTile(
                  title: Text(templates[i]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _removeTemplate(i),
                  ),
                ),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration:
                        const InputDecoration(hintText: 'New comment template'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    _addTemplate(_controller.text);
                    _controller.clear();
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
