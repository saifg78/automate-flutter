import 'dart:html' as html;
import 'package:flutter/material.dart';

class HumanBehaviorSettings extends StatefulWidget {
  const HumanBehaviorSettings({super.key});

  @override
  State<HumanBehaviorSettings> createState() => _HumanBehaviorSettingsState();
}

class _HumanBehaviorSettingsState extends State<HumanBehaviorSettings> {
  int actionDelayMin = 30; // seconds
  int actionDelayMax = 180; // 3 minutes
  int scrollDelayMin = 3;
  int scrollDelayMax = 20;
  double doNothingChance = 15.0; // percent
  int sessionMinutes = 120; // 2 hours
  bool enableNichePrioritization = true;
  String nicheKeywords = 'business, marketing, social media';
  int maxDailySessions = 3;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() {
    actionDelayMin =
        int.tryParse(html.window.localStorage['actionDelayMin'] ?? '30') ?? 30;
    actionDelayMax =
        int.tryParse(html.window.localStorage['actionDelayMax'] ?? '180') ??
            180;
    scrollDelayMin =
        int.tryParse(html.window.localStorage['scrollDelayMin'] ?? '3') ?? 3;
    scrollDelayMax =
        int.tryParse(html.window.localStorage['scrollDelayMax'] ?? '20') ?? 20;
    doNothingChance =
        double.tryParse(html.window.localStorage['doNothingChance'] ?? '15') ??
            15;
    sessionMinutes =
        int.tryParse(html.window.localStorage['sessionMinutes'] ?? '120') ??
            120;
    enableNichePrioritization =
        html.window.localStorage['enableNichePrioritization'] != 'false';
    nicheKeywords = html.window.localStorage['nicheKeywords'] ??
        'business, marketing, social media';
    maxDailySessions =
        int.tryParse(html.window.localStorage['maxDailySessions'] ?? '3') ?? 3;
  }

  void _saveSettings() {
    html.window.localStorage['actionDelayMin'] = actionDelayMin.toString();
    html.window.localStorage['actionDelayMax'] = actionDelayMax.toString();
    html.window.localStorage['scrollDelayMin'] = scrollDelayMin.toString();
    html.window.localStorage['scrollDelayMax'] = scrollDelayMax.toString();
    html.window.localStorage['doNothingChance'] = doNothingChance.toString();
    html.window.localStorage['sessionMinutes'] = sessionMinutes.toString();
    html.window.localStorage['enableNichePrioritization'] =
        enableNichePrioritization.toString();
    html.window.localStorage['nicheKeywords'] = nicheKeywords;
    html.window.localStorage['maxDailySessions'] = maxDailySessions.toString();
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Human behavior settings saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Human Behavior AI System')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Timing Behavior',
                        style: TextStyle(fontSize: 18)),
                    _buildSlider(
                        'Action Delay (min sec)',
                        actionDelayMin.toDouble(),
                        10,
                        60,
                        (v) => actionDelayMin = v.round(),
                        'sec'),
                    _buildSlider(
                        'Action Delay (max sec)',
                        actionDelayMax.toDouble(),
                        30,
                        300,
                        (v) => actionDelayMax = v.round(),
                        'sec'),
                    _buildSlider(
                        'Scroll Delay (min sec)',
                        scrollDelayMin.toDouble(),
                        2,
                        10,
                        (v) => scrollDelayMin = v.round(),
                        'sec'),
                    _buildSlider(
                        'Scroll Delay (max sec)',
                        scrollDelayMax.toDouble(),
                        5,
                        30,
                        (v) => scrollDelayMax = v.round(),
                        'sec'),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Action Randomness',
                        style: TextStyle(fontSize: 18)),
                    _buildSlider('Do Nothing Chance (%)', doNothingChance, 0,
                        40, (v) => doNothingChance = v, '%'),
                    const SizedBox(height: 10),
                    const Text('Human beings sometimes just watch, no action'),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Session & Cooldown',
                        style: TextStyle(fontSize: 18)),
                    _buildSlider(
                        'Max Session Length (min)',
                        sessionMinutes.toDouble(),
                        30,
                        180,
                        (v) => sessionMinutes = v.round(),
                        'min'),
                    _buildSlider(
                        'Max Daily Sessions',
                        maxDailySessions.toDouble(),
                        1,
                        10,
                        (v) => maxDailySessions = v.round(),
                        'sessions'),
                    const Text('After 2 hours session, app takes a break',
                        style: TextStyle(fontSize: 12)),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: const Text('Niche-Based Prioritization'),
                      subtitle: const Text(
                          'Engage more with content matching your keywords'),
                      value: enableNichePrioritization,
                      onChanged: (val) =>
                          setState(() => enableNichePrioritization = val),
                    ),
                    if (enableNichePrioritization)
                      TextField(
                        decoration: const InputDecoration(
                            labelText: 'Niche Keywords (comma separated)'),
                        controller: TextEditingController(text: nicheKeywords),
                        onChanged: (val) => nicheKeywords = val,
                      ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: _saveSettings,
                child: const Text('Save All Behavior Settings')),
            const SizedBox(height: 20),
            const Text(
              'Note: On real device, the app will automatically:\n'
              '- Add random delays between actions (no pattern)\n'
              '- Sometimes like, sometimes comment, sometimes do nothing\n'
              '- Stop after 2 hours session to avoid ban\n'
              '- Prioritize posts with your niche keywords',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSlider(String title, double value, double min, double max,
      Function(double) onChanged, String suffix) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$title: ${value.toInt()} $suffix'),
        Slider(value: value, min: min, max: max, onChanged: onChanged),
      ],
    );
  }
}
