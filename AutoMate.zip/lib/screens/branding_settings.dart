import 'dart:html' as html;
import 'package:flutter/material.dart';

class BrandingSettings extends StatefulWidget {
  const BrandingSettings({super.key});

  @override
  State<BrandingSettings> createState() => _BrandingSettingsState();
}

class _BrandingSettingsState extends State<BrandingSettings> {
  String username = '';
  String position = 'bottom';
  double opacity = 0.7;
  bool hideOldLogo = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() {
    username = html.window.localStorage['brandUsername'] ?? 'your_instagram';
    position = html.window.localStorage['brandPosition'] ?? 'bottom';
    opacity =
        double.tryParse(html.window.localStorage['brandOpacity'] ?? '0.7') ??
            0.7;
    hideOldLogo = html.window.localStorage['hideOldLogo'] != 'false';
  }

  void _saveSettings() {
    html.window.localStorage['brandUsername'] = username;
    html.window.localStorage['brandPosition'] = position;
    html.window.localStorage['brandOpacity'] = opacity.toString();
    html.window.localStorage['hideOldLogo'] = hideOldLogo.toString();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Branding settings saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Auto Branding System')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            TextField(
              decoration:
                  const InputDecoration(labelText: 'Your Instagram Username'),
              onChanged: (val) => username = val,
              controller: TextEditingController(text: username),
            ),
            const SizedBox(height: 20),
            ListTile(
              title: const Text('Overlay Position'),
              subtitle: Text(position),
              trailing: DropdownButton<String>(
                value: position,
                items: ['top', 'bottom', 'center']
                    .map((p) => DropdownMenuItem(value: p, child: Text(p)))
                    .toList(),
                onChanged: (p) => setState(() => position = p!),
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              title: const Text('Opacity'),
              subtitle: Slider(
                value: opacity,
                min: 0.2,
                max: 1.0,
                onChanged: (val) => setState(() => opacity = val),
              ),
              trailing: Text('${(opacity * 100).toInt()}%'),
            ),
            const SizedBox(height: 20),
            SwitchListTile(
              title: const Text('Hide Old Logo / Brand Name'),
              value: hideOldLogo,
              onChanged: (val) => setState(() => hideOldLogo = val),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
                onPressed: _saveSettings,
                child: const Text('Save Branding Settings')),
            const SizedBox(height: 20),
            const Text(
              'Note: On real device, the app will automatically overlay username on images/videos and hide old logos using image processing.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
