import 'dart:html' as html;
import 'package:flutter/material.dart';

class ControlPanel extends StatefulWidget {
  const ControlPanel({super.key});

  @override
  State<ControlPanel> createState() => _ControlPanelState();
}

class _ControlPanelState extends State<ControlPanel> {
  bool autoMode = true;
  int repliesSent = 0;
  int scrollMinutesLeft = 0;
  int leadsFound = 0;

  @override
  void initState() {
    super.initState();
    _loadStats();
    _loadMode();
  }

  void _loadMode() {
    final stored = html.window.localStorage['autoMode'];
    autoMode = stored != 'false'; // default true
  }

  void _loadStats() {
    repliesSent =
        int.tryParse(html.window.localStorage['repliesSent'] ?? '0') ?? 0;
    leadsFound =
        int.tryParse(html.window.localStorage['leadsFound'] ?? '0') ?? 0;
    scrollMinutesLeft =
        int.tryParse(html.window.localStorage['scrollMinutesLeft'] ?? '60') ??
            60;
  }

  void _toggleMode(bool value) {
    setState(() {
      autoMode = value;
    });
    html.window.localStorage['autoMode'] = value.toString();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(autoMode
              ? 'Auto Mode ON'
              : 'Manual Mode ON (auto features disabled)')),
    );
  }

  void _resetStats() {
    setState(() {
      repliesSent = 0;
      leadsFound = 0;
      scrollMinutesLeft = 60;
    });
    html.window.localStorage['repliesSent'] = '0';
    html.window.localStorage['leadsFound'] = '0';
    html.window.localStorage['scrollMinutesLeft'] = '60';
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Stats reset')));
  }

  // Simulate increment (in real app, auto-reply would increment this)
  void _simulateReply() {
    setState(() {
      repliesSent++;
    });
    html.window.localStorage['repliesSent'] = repliesSent.toString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Control Panel')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: SwitchListTile(
                title: const Text('Auto Mode'),
                subtitle:
                    const Text('When ON, app runs automatically in background'),
                value: autoMode,
                onChanged: _toggleMode,
              ),
            ),
            const SizedBox(height: 20),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Real-time Status',
                        style: TextStyle(fontSize: 18)),
                    const Divider(),
                    ListTile(
                      leading: const Icon(Icons.reply_all),
                      title: const Text('Replies Sent'),
                      trailing: Text('$repliesSent'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.timer),
                      title: const Text('Scroll Time Left (min)'),
                      trailing: Text('$scrollMinutesLeft'),
                    ),
                    ListTile(
                      leading: const Icon(Icons.people),
                      title: const Text('Leads Found'),
                      trailing: Text('$leadsFound'),
                    ),
                    ElevatedButton(
                      onPressed: _resetStats,
                      child: const Text('Reset Stats'),
                    ),
                    ElevatedButton(
                      onPressed: _simulateReply,
                      child: const Text('Simulate +1 Reply (test)'),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
