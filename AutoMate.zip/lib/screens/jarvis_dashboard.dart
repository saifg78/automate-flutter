import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';
import 'drive_simulator.dart';
import 'control_panel.dart';
import 'human_behavior_settings.dart';
import 'posting_queue.dart';

class JarvisDashboard extends StatefulWidget {
  const JarvisDashboard({super.key});

  @override
  State<JarvisDashboard> createState() => _JarvisDashboardState();
}

class _JarvisDashboardState extends State<JarvisDashboard> {
  int totalPosts = 0;
  int totalReplies = 0;
  int totalLeads = 0;
  bool autoMode = true;
  bool isRunning = false;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  void _loadStats() {
    totalReplies =
        int.tryParse(html.window.localStorage['repliesSent'] ?? '0') ?? 0;
    totalLeads =
        int.tryParse(html.window.localStorage['leadsFound'] ?? '0') ?? 0;
    totalPosts =
        int.tryParse(html.window.localStorage['totalPosts'] ?? '0') ?? 0;
    autoMode = html.window.localStorage['autoMode'] != 'false';
  }

  void _saveStats() {
    html.window.localStorage['repliesSent'] = totalReplies.toString();
    html.window.localStorage['leadsFound'] = totalLeads.toString();
    html.window.localStorage['totalPosts'] = totalPosts.toString();
  }

  void _toggleRunning() {
    setState(() {
      isRunning = !isRunning;
    });
    if (isRunning) {
      // Simulate start of all automation
      _addLog('🤖 JARVIS Mode ACTIVATED. All systems online.');
      _addLog('📱 Auto-reply, scrolling, posting, engagement started.');
    } else {
      _addLog('🛑 JARVIS Mode DEACTIVATED. Systems stopped.');
    }
  }

  void _addLog(String msg) {
    // Store logs in localStorage for display (optional)
    final logs = html.window.localStorage['jarvisLogs'] ?? '';
    final newLog =
        '${DateTime.now().toLocal().toString().substring(11, 19)} - $msg\n$logs';
    html.window.localStorage['jarvisLogs'] = newLog;
    setState(() {});
  }

  void _simulatePost() {
    if (!isRunning) {
      _addLog('⚠️ JARVIS Mode not running. Start first.');
      return;
    }
    setState(() {
      totalPosts++;
    });
    _saveStats();
    _addLog(
        '📤 Auto-posted content from Drive (simulated). Total posts: $totalPosts');
  }

  void _simulateLead() {
    if (!isRunning) {
      _addLog('⚠️ JARVIS Mode not running.');
      return;
    }
    setState(() {
      totalLeads++;
    });
    _saveStats();
    _addLog('🎯 New lead detected (simulated). Total leads: $totalLeads');
  }

  @override
  Widget build(BuildContext context) {
    final logs = html.window.localStorage['jarvisLogs'] ??
        'No logs yet. Start JARVIS Mode.';
    return Scaffold(
      appBar: AppBar(title: const Text('🤖 JARVIS Mode - Full AI System')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              color: Colors.amber.shade900,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('JARVIS Control Center',
                        style: TextStyle(
                            fontSize: 20, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton.icon(
                          onPressed: _toggleRunning,
                          icon: Icon(isRunning ? Icons.stop : Icons.play_arrow),
                          label:
                              Text(isRunning ? 'Stop JARVIS' : 'Start JARVIS'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                isRunning ? Colors.red : Colors.green,
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: _simulatePost,
                          icon: const Icon(Icons.post_add),
                          label: const Text('Simulate Post'),
                        ),
                        ElevatedButton.icon(
                          onPressed: _simulateLead,
                          icon: const Icon(Icons.people),
                          label: const Text('Simulate Lead'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Column(
                          children: [
                            const Text('Posts', style: TextStyle(fontSize: 12)),
                            Text('$totalPosts',
                                style: const TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        Column(
                          children: [
                            const Text('Replies',
                                style: TextStyle(fontSize: 12)),
                            Text('$totalReplies',
                                style: const TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.bold)),
                          ],
                        ),
                        Column(
                          children: [
                            const Text('Leads', style: TextStyle(fontSize: 12)),
                            Text('$totalLeads',
                                style: const TextStyle(
                                    fontSize: 24, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const ControlPanel())),
                    child: const Text('Control Panel'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const DriveSimulator())),
                    child: const Text('Drive Manager'),
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => const HumanBehaviorSettings())),
                    child: const Text('AI Behavior'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: Card(
                child: Padding(
                  padding: const EdgeInsets.all(8),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text('System Logs',
                          style: TextStyle(fontWeight: FontWeight.bold)),
                      const Divider(),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Text(logs,
                              style: const TextStyle(
                                  fontFamily: 'monospace', fontSize: 12)),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
