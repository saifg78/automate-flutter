import 'dart:async';
import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';

class SimulationMode extends StatefulWidget {
  const SimulationMode({super.key});

  @override
  State<SimulationMode> createState() => _SimulationModeState();
}

class _SimulationModeState extends State<SimulationMode> {
  final List<String> _log = [];
  bool _isAutoReplyActive = false;
  List<String> _templates = [];
  bool _isScrolling = false;
  Timer? _scrollTimer;

  // Phase 6: Human behavior variables
  bool _humanBehaviorEnabled = false;
  List<String> _commentTemplates = [];
  List<String> _nicheKeywords = [];

  @override
  void initState() {
    super.initState();
    _loadData();
    _loadHumanBehavior();
  }

  void _loadData() {
    _isAutoReplyActive = html.window.localStorage['autoReplyActive'] == 'true';
    final storedTemplates = html.window.localStorage['replyTemplates'];
    if (storedTemplates != null) {
      String data = storedTemplates;
      final encryptionEnabled =
          html.window.localStorage['encryptionEnabled'] == 'true';
      if (encryptionEnabled) {
        try {
          data = utf8.decode(base64.decode(data));
        } catch (_) {}
      }
      _templates = List<String>.from(jsonDecode(data));
    } else {
      _templates = [];
    }
  }

  void _loadHumanBehavior() {
    _humanBehaviorEnabled =
        html.window.localStorage['enableNichePrioritization'] != 'false';
    final storedComments = html.window.localStorage['commentTemplates'];
    if (storedComments != null) {
      _commentTemplates = List<String>.from(jsonDecode(storedComments));
    }
    final keywords = html.window.localStorage['nicheKeywords'] ?? '';
    _nicheKeywords =
        keywords.split(',').map((e) => e.trim().toLowerCase()).toList();
  }

  void _addLog(String msg) {
    setState(() {
      _log.insert(
          0, '${DateTime.now().toLocal().toString().substring(11, 19)} - $msg');
      if (_log.length > 50) _log.removeLast();
    });
  }

  void _simulateReply() {
    if (!_isAutoReplyActive) {
      _addLog('⚠️ Auto-reply is OFF. Turn it on in settings.');
      return;
    }
    if (_templates.isEmpty) {
      _addLog('❌ No reply templates. Add some in Auto-Reply Settings.');
      return;
    }
    _addLog('📩 Incoming message (simulated)');
    // random delay between 3 and 20 seconds
    int delaySec = 3 + DateTime.now().second % 18;
    Future.delayed(Duration(seconds: delaySec), () {
      // random template
      final random = _templates[DateTime.now().millisecond % _templates.length];
      _addLog('🤖 Auto-reply: "$random"');
    });
  }

  Future<void> _simulateScroll() async {
    if (_isScrolling) {
      _addLog('⏸️ Scroll session already running');
      return;
    }
    setState(() => _isScrolling = true);
    _addLog('🔄 Starting simulated auto-scroll session');

    // Load settings
    int scrollMin =
        int.tryParse(html.window.localStorage['scrollMin'] ?? '3') ?? 3;
    int scrollMax =
        int.tryParse(html.window.localStorage['scrollMax'] ?? '8') ?? 8;
    int pauseMin =
        int.tryParse(html.window.localStorage['pauseMin'] ?? '10') ?? 10;
    int pauseMax =
        int.tryParse(html.window.localStorage['pauseMax'] ?? '15') ?? 15;
    double skipChance =
        double.tryParse(html.window.localStorage['skipChance'] ?? '20') ?? 20;
    int sessionMinutes =
        int.tryParse(html.window.localStorage['sessionMinutes'] ?? '60') ?? 60;

    DateTime endTime = DateTime.now().add(Duration(minutes: sessionMinutes));

    while (DateTime.now().isBefore(endTime) && _isScrolling) {
      // scroll duration
      int scrollSec =
          scrollMin + (DateTime.now().second % (scrollMax - scrollMin + 1));
      _addLog('📱 Scrolling for $scrollSec sec');
      await Future.delayed(Duration(seconds: scrollSec));
      if (!_isScrolling) break;

      // random skip
      bool skip = (DateTime.now().millisecond % 100) < skipChance;
      if (skip) {
        _addLog('⏭️ Skipped post');
      } else {
        _addLog('❤️ Liked post (simulated)');
      }

      // pause
      int pauseSec =
          pauseMin + (DateTime.now().millisecond % (pauseMax - pauseMin + 1));
      _addLog('⏸️ Pausing $pauseSec sec');
      await Future.delayed(Duration(seconds: pauseSec));
    }

    if (mounted) {
      setState(() => _isScrolling = false);
      _addLog('🛑 Scroll session finished or stopped');
    }
  }

  void _stopScroll() {
    if (_isScrolling) {
      setState(() => _isScrolling = false);
      _addLog('🛑 Scroll stopped by user');
    } else {
      _addLog('⚠️ No scroll session running');
    }
  }

  // Phase 6: Simulate human-like action (like/comment/do nothing)
  void _simulateHumanAction() {
    if (!_humanBehaviorEnabled) {
      _addLog(
          '🤖 Human behavior AI is disabled. Enable in Human Behavior Settings.');
      return;
    }
    // Simulate random action based on doNothingChance
    final doNothingChance =
        double.tryParse(html.window.localStorage['doNothingChance'] ?? '15') ??
            15;
    final isDoNothing = (DateTime.now().millisecond % 100) < doNothingChance;
    if (isDoNothing) {
      _addLog('😐 Human behavior: Did nothing (just watched)');
      return;
    }
    // Randomly like or comment
    final actionType = DateTime.now().millisecond % 2; // 0=like, 1=comment
    if (actionType == 0) {
      _addLog('❤️ Human behavior: Liked post');
    } else {
      if (_commentTemplates.isNotEmpty) {
        final randomComment = _commentTemplates[
            DateTime.now().millisecond % _commentTemplates.length];
        _addLog('💬 Human behavior: Commented "$randomComment"');
      } else {
        _addLog(
            '💬 Human behavior: Would comment but no templates, just liked');
        _addLog('❤️ Liked post instead');
      }
    }
  }

  // Simulate niche-based prioritization: check if a keyword matches
  void _simulateNicheCheck() {
    if (!_humanBehaviorEnabled || _nicheKeywords.isEmpty) {
      _addLog('⚠️ Niche prioritization disabled or no keywords set.');
      return;
    }
    final samplePost =
        "Check out this amazing business growth strategy! #marketing";
    _addLog('📝 Sample post: "$samplePost"');
    bool matched = false;
    for (var kw in _nicheKeywords) {
      if (samplePost.toLowerCase().contains(kw)) {
        matched = true;
        break;
      }
    }
    if (matched) {
      _addLog('🎯 Niche match detected! App will prioritize this content.');
    } else {
      _addLog('❌ No niche keyword match. App may scroll past.');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Simulation Mode (Test)')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: [
                ElevatedButton.icon(
                  onPressed: _simulateReply,
                  icon: const Icon(Icons.message),
                  label: const Text('Simulate Msg'),
                ),
                if (_isScrolling)
                  ElevatedButton.icon(
                    onPressed: _stopScroll,
                    icon: const Icon(Icons.stop),
                    label: const Text('Stop Scroll'),
                    style:
                        ElevatedButton.styleFrom(backgroundColor: Colors.red),
                  )
                else
                  ElevatedButton.icon(
                    onPressed: _simulateScroll,
                    icon: const Icon(Icons.swap_vert),
                    label: const Text('Simulate Scroll'),
                  ),
                // Phase 6 buttons
                ElevatedButton.icon(
                  onPressed: _simulateHumanAction,
                  icon: const Icon(Icons.psychology),
                  label: const Text('Simulate Human Action'),
                ),
                ElevatedButton.icon(
                  onPressed: _simulateNicheCheck,
                  icon: const Icon(Icons.search),
                  label: const Text('Test Niche Match'),
                ),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              reverse: true,
              itemCount: _log.length,
              itemBuilder: (ctx, i) => ListTile(
                title: Text(_log[i],
                    style: const TextStyle(fontFamily: 'monospace')),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
