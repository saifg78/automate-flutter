import 'dart:html' as html;
import 'package:flutter/material.dart';

class ClientHunter extends StatefulWidget {
  const ClientHunter({super.key});

  @override
  State<ClientHunter> createState() => _ClientHunterState();
}

class _ClientHunterState extends State<ClientHunter> {
  List<String> leads = [];
  String searchKeyword = 'business';
  bool huntingActive = false;

  @override
  void initState() {
    super.initState();
    _loadLeads();
  }

  void _loadLeads() {
    final stored = html.window.localStorage['leadsList'];
    if (stored != null) {
      leads = stored.split(',');
    } else {
      leads = [];
    }
  }

  void _saveLeads() {
    html.window.localStorage['leadsList'] = leads.join(',');
    html.window.localStorage['leadsFound'] = leads.length.toString();
  }

  void _simulateHunt() {
    setState(() {
      huntingActive = true;
    });
    // Simulate searching for leads based on keyword
    final dummyLeads = [
      'john_doe_business',
      'sarah_marketing',
      'alex_social',
      'priya_entrepreneur',
      'rahul_digital',
    ];
    final newLeads =
        dummyLeads.where((l) => l.contains(searchKeyword)).toList();
    for (var lead in newLeads) {
      if (!leads.contains(lead)) {
        leads.add(lead);
      }
    }
    _saveLeads();
    Future.delayed(const Duration(seconds: 2), () {
      setState(() {
        huntingActive = false;
      });
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Found ${newLeads.length} new leads!')));
    });
  }

  void _deleteLead(int index) {
    setState(() {
      leads.removeAt(index);
    });
    _saveLeads();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Client Hunting System')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    decoration: const InputDecoration(
                        labelText:
                            'Search Keyword (e.g., business, marketing)'),
                    onChanged: (val) => searchKeyword = val,
                    controller: TextEditingController(text: searchKeyword),
                  ),
                ),
                const SizedBox(width: 10),
                ElevatedButton.icon(
                  onPressed: huntingActive ? null : _simulateHunt,
                  icon: huntingActive
                      ? const SizedBox(
                          width: 20,
                          height: 20,
                          child: CircularProgressIndicator(strokeWidth: 2))
                      : const Icon(Icons.search),
                  label: Text(huntingActive ? 'Hunting...' : 'Hunt Clients'),
                ),
              ],
            ),
            const SizedBox(height: 20),
            const Text('Leads Found', style: TextStyle(fontSize: 18)),
            Expanded(
              child: leads.isEmpty
                  ? const Center(
                      child: Text(
                          'No leads yet. Click "Hunt Clients" to simulate.'))
                  : ListView.builder(
                      itemCount: leads.length,
                      itemBuilder: (ctx, i) => ListTile(
                        leading: const Icon(Icons.person),
                        title: Text(leads[i]),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteLead(i),
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
