import 'dart:html' as html;
import 'package:flutter/material.dart';

class EditingSettings extends StatefulWidget {
  const EditingSettings({super.key});

  @override
  State<EditingSettings> createState() => _EditingSettingsState();
}

class _EditingSettingsState extends State<EditingSettings> {
  bool convertToStory = true;
  bool useBackgroundBlur = false;
  bool batchProcessing = true;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() {
    convertToStory = html.window.localStorage['convertToStory'] != 'false';
    useBackgroundBlur = html.window.localStorage['useBackgroundBlur'] == 'true';
    batchProcessing = html.window.localStorage['batchProcessing'] != 'false';
  }

  void _saveSettings() {
    html.window.localStorage['convertToStory'] = convertToStory.toString();
    html.window.localStorage['useBackgroundBlur'] =
        useBackgroundBlur.toString();
    html.window.localStorage['batchProcessing'] = batchProcessing.toString();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Editing settings saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Content Editing System')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            SwitchListTile(
              title: const Text('Convert to Story Format (9:16)'),
              subtitle: const Text('Normal images will be cropped or resized'),
              value: convertToStory,
              onChanged: (val) => setState(() => convertToStory = val),
            ),
            if (convertToStory)
              SwitchListTile(
                title: const Text('Use Background Blur (instead of crop)'),
                subtitle: const Text('Blur background instead of cropping'),
                value: useBackgroundBlur,
                onChanged: (val) => setState(() => useBackgroundBlur = val),
              ),
            SwitchListTile(
              title: const Text('Batch Processing'),
              subtitle: const Text('Process multiple files at once'),
              value: batchProcessing,
              onChanged: (val) => setState(() => batchProcessing = val),
            ),
            const SizedBox(height: 30),
            ElevatedButton(
                onPressed: _saveSettings,
                child: const Text('Save Editing Settings')),
            const SizedBox(height: 20),
            const Text(
              'Note: On real device, the app will automatically convert images to 9:16 story format, apply blur if needed, and process batches.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
