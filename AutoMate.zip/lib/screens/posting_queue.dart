import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/queue_item.dart';
import '../models/content_item.dart'; // from Phase 3

class PostingQueue extends StatefulWidget {
  const PostingQueue({super.key});

  @override
  State<PostingQueue> createState() => _PostingQueueState();
}

class _PostingQueueState extends State<PostingQueue> {
  List<QueueItem> queue = [];
  int imagesBeforeVideo = 4; // 4 images then 2 videos
  int videosAfterImages = 2;
  bool autoPost = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    _buildQueueFromDrive();
  }

  void _loadSettings() {
    imagesBeforeVideo =
        int.tryParse(html.window.localStorage['imagesBeforeVideo'] ?? '4') ?? 4;
    videosAfterImages =
        int.tryParse(html.window.localStorage['videosAfterImages'] ?? '2') ?? 2;
    autoPost = html.window.localStorage['autoPost'] == 'true';
  }

  void _saveSequenceSettings() {
    html.window.localStorage['imagesBeforeVideo'] =
        imagesBeforeVideo.toString();
    html.window.localStorage['videosAfterImages'] =
        videosAfterImages.toString();
    html.window.localStorage['autoPost'] = autoPost.toString();
    _buildQueueFromDrive();
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Sequence saved & queue rebuilt')));
  }

  void _buildQueueFromDrive() {
    // Load content items from Drive Simulator (Phase 3)
    final stored = html.window.localStorage['driveItems'];
    if (stored == null) return;

    List<ContentItem> allItems = (jsonDecode(stored) as List)
        .map((e) => ContentItem.fromJson(e))
        .toList();

    // Separate unused images and videos
    List<ContentItem> unusedImages =
        allItems.where((i) => i.type == 'image' && !i.used).toList();
    List<ContentItem> unusedVideos =
        allItems.where((i) => i.type == 'video' && !i.used).toList();

    List<QueueItem> newQueue = [];
    int order = 0;
    // Build sequence: imagesBeforeVideo images, then videosAfterImages videos, repeat
    int imgIndex = 0, vidIndex = 0;
    while (imgIndex < unusedImages.length || vidIndex < unusedVideos.length) {
      // add images
      for (int i = 0;
          i < imagesBeforeVideo && imgIndex < unusedImages.length;
          i++) {
        final img = unusedImages[imgIndex++];
        newQueue.add(QueueItem(
          id: img.id,
          fileName: img.name,
          type: 'image',
          orderIndex: order++,
          posted: false,
        ));
      }
      // add videos
      for (int i = 0;
          i < videosAfterImages && vidIndex < unusedVideos.length;
          i++) {
        final vid = unusedVideos[vidIndex++];
        newQueue.add(QueueItem(
          id: vid.id,
          fileName: vid.name,
          type: 'video',
          orderIndex: order++,
          posted: false,
        ));
      }
    }

    setState(() {
      queue = newQueue;
    });
    // save queue to localStorage
    html.window.localStorage['postingQueue'] =
        jsonEncode(queue.map((e) => e.toJson()).toList());
  }

  void _markPosted(int index) {
    setState(() {
      queue[index].posted = true;
    });
    // Also mark the corresponding content item as used in driveItems
    final stored = html.window.localStorage['driveItems'];
    if (stored != null) {
      List<ContentItem> items = (jsonDecode(stored) as List)
          .map((e) => ContentItem.fromJson(e))
          .toList();
      final itemIndex = items.indexWhere((e) => e.id == queue[index].id);
      if (itemIndex != -1) {
        items[itemIndex].used = true;
        html.window.localStorage['driveItems'] =
            jsonEncode(items.map((e) => e.toJson()).toList());
      }
    }
    _saveQueue();
  }

  void _saveQueue() {
    html.window.localStorage['postingQueue'] =
        jsonEncode(queue.map((e) => e.toJson()).toList());
  }

  void _simulateAutoPost() {
    if (!autoPost) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Auto-post is disabled. Enable it in settings.')));
      return;
    }
    // Find first not posted item
    int firstNotPosted = queue.indexWhere((e) => !e.posted);
    if (firstNotPosted == -1) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text(
              'Queue is empty or all posted! Reset from Drive Simulator.')));
      return;
    }
    _markPosted(firstNotPosted);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Auto-posted: ${queue[firstNotPosted].fileName}')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sequential Posting Queue')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child:
                              Text('Images before video: $imagesBeforeVideo'),
                        ),
                        Slider(
                          value: imagesBeforeVideo.toDouble(),
                          min: 1,
                          max: 10,
                          divisions: 9,
                          onChanged: (v) =>
                              setState(() => imagesBeforeVideo = v.round()),
                        ),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                          child:
                              Text('Videos after images: $videosAfterImages'),
                        ),
                        Slider(
                          value: videosAfterImages.toDouble(),
                          min: 1,
                          max: 5,
                          divisions: 4,
                          onChanged: (v) =>
                              setState(() => videosAfterImages = v.round()),
                        ),
                      ],
                    ),
                    SwitchListTile(
                      title: const Text('Auto Post (simulated)'),
                      value: autoPost,
                      onChanged: (val) => setState(() => autoPost = val),
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        ElevatedButton(
                            onPressed: _saveSequenceSettings,
                            child: const Text('Save & Rebuild Queue')),
                        ElevatedButton(
                            onPressed: _simulateAutoPost,
                            child: const Text('Simulate Auto-Post Next')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            const Text('Posting Queue (in sequence)',
                style: TextStyle(fontSize: 18)),
            Expanded(
              child: ListView.builder(
                itemCount: queue.length,
                itemBuilder: (ctx, i) => ListTile(
                  leading: Icon(queue[i].type == 'image'
                      ? Icons.image
                      : Icons.video_library),
                  title: Text(queue[i].fileName),
                  subtitle: Text('Order: ${queue[i].orderIndex}'),
                  trailing: queue[i].posted
                      ? const Icon(Icons.check_circle, color: Colors.green)
                      : ElevatedButton(
                          onPressed: () => _markPosted(i),
                          child: const Text('Mark Posted'),
                        ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
