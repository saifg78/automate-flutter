import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';

class SecuritySettings extends StatefulWidget {
  const SecuritySettings({super.key});

  @override
  State<SecuritySettings> createState() => _SecuritySettingsState();
}

class _SecuritySettingsState extends State<SecuritySettings> {
  bool encryptionEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadEncryptionSetting();
  }

  void _loadEncryptionSetting() {
    final val = html.window.localStorage['encryptionEnabled'];
    encryptionEnabled = val == 'true';
  }

  void _toggleEncryption(bool value) {
    html.window.localStorage['encryptionEnabled'] = value.toString();
    setState(() {
      encryptionEnabled = value;
    });
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
          content: Text(value ? 'Encryption enabled' : 'Encryption disabled')),
    );
  }

  void _deleteAllData() {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete All Data?'),
        content: const Text(
            'This will delete all your reply templates, scroll settings, and phase progress. This cannot be undone.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              // Clear all localStorage keys used by app
              html.window.localStorage.remove('autoReplyActive');
              html.window.localStorage.remove('replyTemplates');
              html.window.localStorage.remove('scrollMin');
              html.window.localStorage.remove('scrollMax');
              html.window.localStorage.remove('pauseMin');
              html.window.localStorage.remove('pauseMax');
              html.window.localStorage.remove('skipChance');
              html.window.localStorage.remove('sessionMinutes');
              html.window.localStorage.remove('encryptionEnabled');
              // Don't delete phase? Or delete? Let's keep phase but reset others.
              // For security, we can keep phase as is, but reset everything else.
              Navigator.pop(ctx);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                    content: Text('All data deleted (except phase progress)')),
              );
            },
            child: const Text('Delete', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Security Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Enable Encryption'),
              subtitle: const Text(
                  'Simulated base64 encoding (real encryption on device)'),
              value: encryptionEnabled,
              onChanged: _toggleEncryption,
            ),
            const Divider(),
            const SizedBox(height: 20),
            Card(
              color: Colors.red.shade900,
              child: ListTile(
                leading: const Icon(Icons.delete_forever, color: Colors.white),
                title: const Text('Delete All App Data',
                    style: TextStyle(color: Colors.white)),
                subtitle: const Text('Templates, settings, everything',
                    style: TextStyle(color: Colors.white70)),
                onTap: _deleteAllData,
              ),
            ),
            const SizedBox(height: 20),
            const Text(
              'Note: In this web simulation, data is stored in your browser\'s local storage.\n'
              'On a real Android device, data will be stored in app private storage (not gallery).',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
