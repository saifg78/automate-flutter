import 'dart:html' as html;
import 'package:flutter/material.dart';

class DailyPoster extends StatefulWidget {
  const DailyPoster({super.key});

  @override
  State<DailyPoster> createState() => _DailyPosterState();
}

class _DailyPosterState extends State<DailyPoster> {
  TimeOfDay postTime = const TimeOfDay(hour: 10, minute: 0);
  TimeOfDay storyTime = const TimeOfDay(hour: 18, minute: 0);
  bool postEnabled = true;
  bool storyEnabled = true;
  String lastPostStatus = 'No post yet today';

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  void _loadSettings() {
    final postHour =
        int.tryParse(html.window.localStorage['postHour'] ?? '10') ?? 10;
    final postMin =
        int.tryParse(html.window.localStorage['postMin'] ?? '0') ?? 0;
    final storyHour =
        int.tryParse(html.window.localStorage['storyHour'] ?? '18') ?? 18;
    final storyMin =
        int.tryParse(html.window.localStorage['storyMin'] ?? '0') ?? 0;
    postTime = TimeOfDay(hour: postHour, minute: postMin);
    storyTime = TimeOfDay(hour: storyHour, minute: storyMin);
    postEnabled = html.window.localStorage['postEnabled'] != 'false';
    storyEnabled = html.window.localStorage['storyEnabled'] != 'false';
  }

  void _saveSettings() {
    html.window.localStorage['postHour'] = postTime.hour.toString();
    html.window.localStorage['postMin'] = postTime.minute.toString();
    html.window.localStorage['storyHour'] = storyTime.hour.toString();
    html.window.localStorage['storyMin'] = storyTime.minute.toString();
    html.window.localStorage['postEnabled'] = postEnabled.toString();
    html.window.localStorage['storyEnabled'] = storyEnabled.toString();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Schedule saved. Auto-posting will run at set times.')));
  }

  void _simulatePostNow() {
    // Simulate posting
    setState(() {
      lastPostStatus =
          'Post simulated at ${DateTime.now().toLocal().toString().substring(11, 16)}';
    });
    // Increment total posts count in JARVIS
    int totalPosts =
        int.tryParse(html.window.localStorage['totalPosts'] ?? '0') ?? 0;
    totalPosts++;
    html.window.localStorage['totalPosts'] = totalPosts.toString();
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
        content: Text('Post simulated! Check JARVIS dashboard.')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Daily Post & Story Scheduler')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            SwitchListTile(
              title: const Text('Enable Daily Post'),
              subtitle: const Text('Auto-post once per day'),
              value: postEnabled,
              onChanged: (val) => setState(() => postEnabled = val),
            ),
            ListTile(
              leading: const Icon(Icons.access_time),
              title: const Text('Post Time'),
              trailing: Text(postTime.format(context)),
              onTap: () async {
                final newTime = await showTimePicker(
                    context: context, initialTime: postTime);
                if (newTime != null) setState(() => postTime = newTime);
              },
            ),
            const Divider(),
            SwitchListTile(
              title: const Text('Enable Daily Story'),
              subtitle: const Text('Auto-post story once per day'),
              value: storyEnabled,
              onChanged: (val) => setState(() => storyEnabled = val),
            ),
            ListTile(
              leading: const Icon(Icons.access_time),
              title: const Text('Story Time'),
              trailing: Text(storyTime.format(context)),
              onTap: () async {
                final newTime = await showTimePicker(
                    context: context, initialTime: storyTime);
                if (newTime != null) setState(() => storyTime = newTime);
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: _saveSettings, child: const Text('Save Schedule')),
            const SizedBox(height: 20),
            ElevatedButton.icon(
              onPressed: _simulatePostNow,
              icon: const Icon(Icons.post_add),
              label: const Text('Simulate Post Now (Test)'),
            ),
            const SizedBox(height: 20),
            Card(
              child: ListTile(
                title: const Text('Last Post Status'),
                subtitle: Text(lastPostStatus),
              ),
            ),
            const Text(
              'Note: On real device, app will automatically post at scheduled times using content from Google Drive. Here you can simulate.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
