import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';
import '../models/content_item.dart';

class DriveSimulator extends StatefulWidget {
  const DriveSimulator({super.key});

  @override
  State<DriveSimulator> createState() => _DriveSimulatorState();
}

class _DriveSimulatorState extends State<DriveSimulator> {
  List<ContentItem> items = [];
  String selectedFolder = 'Default Folder';
  final List<String> folders = [
    'Default Folder',
    'Marketing',
    'Products',
    'Promos'
  ];

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    final stored = html.window.localStorage['driveItems'];
    if (stored != null) {
      final List<dynamic> decoded = jsonDecode(stored);
      items = decoded.map((e) => ContentItem.fromJson(e)).toList();
    } else {
      // Create dummy files
      items = List.generate(
          10,
          (i) => ContentItem(
                id: 'file$i',
                name:
                    '${i < 5 ? 'image' : 'video'}_$i.${i < 5 ? 'jpg' : 'mp4'}',
                type: i < 5 ? 'image' : 'video',
              ));
      _saveItems();
    }
    final folder = html.window.localStorage['selectedDriveFolder'];
    if (folder != null) selectedFolder = folder;
  }

  void _saveItems() {
    html.window.localStorage['driveItems'] =
        jsonEncode(items.map((e) => e.toJson()).toList());
  }

  void _selectFolder(String? folder) {
    if (folder != null) {
      setState(() {
        selectedFolder = folder;
      });
      html.window.localStorage['selectedDriveFolder'] = folder;
      // In real app, would fetch new files from Drive. Here we simulate same files.
      ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Folder changed to $folder (simulated)')));
    }
  }

  void _resetUsedFlags() {
    setState(() {
      for (var item in items) {
        item.used = false;
      }
    });
    _saveItems();
    ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('All files reset (ready for reposting)')));
  }

  void _markUsed(String id) {
    final index = items.indexWhere((e) => e.id == id);
    if (index != -1) {
      setState(() {
        items[index].used = true;
      });
      _saveItems();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Google Drive Simulator')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            DropdownButtonFormField<String>(
              value: selectedFolder,
              items: folders
                  .map((f) => DropdownMenuItem(value: f, child: Text(f)))
                  .toList(),
              onChanged: _selectFolder,
              decoration: const InputDecoration(labelText: 'Select Folder'),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text('Content Items (simulated)',
                    style: TextStyle(fontSize: 18)),
                ElevatedButton.icon(
                  onPressed: _resetUsedFlags,
                  icon: const Icon(Icons.refresh),
                  label: const Text('Reset All Used Flags'),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: items.length,
                itemBuilder: (ctx, i) {
                  final item = items[i];
                  return ListTile(
                    leading: Icon(item.type == 'image'
                        ? Icons.image
                        : Icons.video_library),
                    title: Text(item.name),
                    subtitle: Text(
                        item.used ? 'Used (will not repeat)' : 'Available'),
                    trailing: item.used
                        ? const Icon(Icons.check_circle, color: Colors.green)
                        : ElevatedButton(
                            onPressed: () => _markUsed(item.id),
                            child: const Text('Mark Used'),
                          ),
                  );
                },
              ),
            ),
            const Text(
              'Note: In real app, this will connect to actual Google Drive API.\n'
              'Here we simulate the "no repeat" logic.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
