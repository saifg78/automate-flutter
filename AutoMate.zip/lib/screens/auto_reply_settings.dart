import 'dart:html' as html;
import 'dart:convert';
import 'package:flutter/material.dart';

class AutoReplySettings extends StatefulWidget {
  const AutoReplySettings({super.key});

  @override
  State<AutoReplySettings> createState() => _AutoReplySettingsState();
}

class _AutoReplySettingsState extends State<AutoReplySettings> {
  bool isActive = false;
  List<String> templates = [];

  bool get _encryptionEnabled =>
      html.window.localStorage['encryptionEnabled'] == 'true';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    final storedActive = html.window.localStorage['autoReplyActive'];
    isActive = storedActive == 'true';

    final storedTemplates = html.window.localStorage['replyTemplates'];
    if (storedTemplates != null) {
      String data = storedTemplates;
      if (_encryptionEnabled) {
        // simple base64 decode simulation
        try {
          data = utf8.decode(base64.decode(data));
        } catch (_) {}
      }
      templates = List<String>.from(jsonDecode(data));
    } else {
      templates = [
        "I'm busy, will reply soon.",
        "Thanks! I'll get back to you.",
        "Hello! I'll respond shortly."
      ];
      _saveTemplates();
    }
  }

  void _saveActive(bool val) {
    html.window.localStorage['autoReplyActive'] = val.toString();
    setState(() {
      isActive = val;
    });
  }

  void _saveTemplates() {
    String jsonData = jsonEncode(templates);
    if (_encryptionEnabled) {
      jsonData = base64.encode(utf8.encode(jsonData));
    }
    html.window.localStorage['replyTemplates'] = jsonData;
  }

  void _addTemplate(String text) {
    if (text.trim().isEmpty) return;
    setState(() {
      templates.add(text.trim());
    });
    _saveTemplates();
  }

  void _removeTemplate(int index) {
    setState(() {
      templates.removeAt(index);
    });
    _saveTemplates();
  }

  final TextEditingController _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Auto-Reply Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            SwitchListTile(
              title: const Text('Active Mode'),
              subtitle: const Text('When ON, app will auto-reply'),
              value: isActive,
              onChanged: _saveActive,
            ),
            const Divider(),
            const Text('Reply Templates (randomly selected)'),
            const SizedBox(height: 8),
            Expanded(
              child: ListView.builder(
                itemCount: templates.length,
                itemBuilder: (ctx, i) => ListTile(
                  title: Text(templates[i]),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete),
                    onPressed: () => _removeTemplate(i),
                  ),
                ),
              ),
            ),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration:
                        const InputDecoration(hintText: 'New reply message'),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.add),
                  onPressed: () {
                    _addTemplate(_controller.text);
                    _controller.clear();
                  },
                ),
              ],
            ),
            if (_encryptionEnabled)
              const Padding(
                padding: EdgeInsets.only(top: 8),
                child: Text('🔒 Encryption is ON. Your data is stored encoded.',
                    style: TextStyle(fontSize: 12, color: Colors.green)),
              ),
          ],
        ),
      ),
    );
  }
}
