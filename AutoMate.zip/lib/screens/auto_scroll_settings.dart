import 'dart:html' as html;
import 'package:flutter/material.dart';

class AutoScrollSettings extends StatefulWidget {
  const AutoScrollSettings({super.key});

  @override
  State<AutoScrollSettings> createState() => _AutoScrollSettingsState();
}

class _AutoScrollSettingsState extends State<AutoScrollSettings> {
  int scrollMin = 3,
      scrollMax = 8,
      pauseMin = 10,
      pauseMax = 15,
      sessionMinutes = 60;
  double skipChance = 20;

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  void _loadData() {
    scrollMin = int.tryParse(html.window.localStorage['scrollMin'] ?? '3') ?? 3;
    scrollMax = int.tryParse(html.window.localStorage['scrollMax'] ?? '8') ?? 8;
    pauseMin = int.tryParse(html.window.localStorage['pauseMin'] ?? '10') ?? 10;
    pauseMax = int.tryParse(html.window.localStorage['pauseMax'] ?? '15') ?? 15;
    skipChance =
        double.tryParse(html.window.localStorage['skipChance'] ?? '20') ?? 20;
    sessionMinutes =
        int.tryParse(html.window.localStorage['sessionMinutes'] ?? '60') ?? 60;
  }

  void _saveAll() {
    html.window.localStorage['scrollMin'] = scrollMin.toString();
    html.window.localStorage['scrollMax'] = scrollMax.toString();
    html.window.localStorage['pauseMin'] = pauseMin.toString();
    html.window.localStorage['pauseMax'] = pauseMax.toString();
    html.window.localStorage['skipChance'] = skipChance.toString();
    html.window.localStorage['sessionMinutes'] = sessionMinutes.toString();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Settings saved')));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Auto Scroll Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildSlider('Scroll min (sec)', scrollMin.toDouble(), 2, 15,
                (v) => scrollMin = v.round()),
            _buildSlider('Scroll max (sec)', scrollMax.toDouble(), 2, 15,
                (v) => scrollMax = v.round()),
            _buildSlider('Pause min (sec)', pauseMin.toDouble(), 5, 30,
                (v) => pauseMin = v.round()),
            _buildSlider('Pause max (sec)', pauseMax.toDouble(), 5, 30,
                (v) => pauseMax = v.round()),
            _buildSlider(
                'Skip chance (%)', skipChance, 0, 100, (v) => skipChance = v),
            _buildSlider('Session time (min)', sessionMinutes.toDouble(), 10,
                120, (v) => sessionMinutes = v.round()),
            const SizedBox(height: 20),
            ElevatedButton(
                onPressed: _saveAll, child: const Text('Save Settings')),
          ],
        ),
      ),
    );
  }

  Widget _buildSlider(String title, double value, double min, double max,
      Function(double) onChanged) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$title: ${value.toInt()}'),
        Slider(value: value, min: min, max: max, onChanged: onChanged),
      ],
    );
  }
}
