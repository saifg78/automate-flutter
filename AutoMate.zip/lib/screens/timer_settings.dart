import 'dart:html' as html;
import 'package:flutter/material.dart';
import '../services/timer_simulator.dart';

class TimerSettings extends StatefulWidget {
  const TimerSettings({super.key});

  @override
  State<TimerSettings> createState() => _TimerSettingsState();
}

class _TimerSettingsState extends State<TimerSettings> {
  int instagramMinutes = 60;
  int whatsappMinutes = 60;
  TimeOfDay startTime = const TimeOfDay(hour: 9, minute: 0);
  TimeOfDay endTime = const TimeOfDay(hour: 22, minute: 0);
  bool scheduleEnabled = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
    TimerSimulator.loadSettings();
    TimerSimulator.onInstagramTick = _updateInstagramDisplay;
    TimerSimulator.onWhatsAppTick = _updateWhatsAppDisplay;
  }

  void _loadSettings() {
    instagramMinutes =
        int.tryParse(html.window.localStorage['instagramMinutes'] ?? '60') ??
            60;
    whatsappMinutes =
        int.tryParse(html.window.localStorage['whatsappMinutes'] ?? '60') ?? 60;
    scheduleEnabled = html.window.localStorage['scheduleEnabled'] == 'true';
    final startHour =
        int.tryParse(html.window.localStorage['startHour'] ?? '9') ?? 9;
    final startMinute =
        int.tryParse(html.window.localStorage['startMinute'] ?? '0') ?? 0;
    final endHour =
        int.tryParse(html.window.localStorage['endHour'] ?? '22') ?? 22;
    final endMinute =
        int.tryParse(html.window.localStorage['endMinute'] ?? '0') ?? 0;
    startTime = TimeOfDay(hour: startHour, minute: startMinute);
    endTime = TimeOfDay(hour: endHour, minute: endMinute);
  }

  void _saveInstagramMinutes(int val) {
    setState(() => instagramMinutes = val);
    html.window.localStorage['instagramMinutes'] = val.toString();
  }

  void _saveWhatsAppMinutes(int val) {
    setState(() => whatsappMinutes = val);
    html.window.localStorage['whatsappMinutes'] = val.toString();
  }

  void _saveSchedule(bool val) {
    setState(() => scheduleEnabled = val);
    html.window.localStorage['scheduleEnabled'] = val.toString();
  }

  void _saveStartTime(TimeOfDay time) {
    setState(() => startTime = time);
    html.window.localStorage['startHour'] = time.hour.toString();
    html.window.localStorage['startMinute'] = time.minute.toString();
  }

  void _saveEndTime(TimeOfDay time) {
    setState(() => endTime = time);
    html.window.localStorage['endHour'] = time.hour.toString();
    html.window.localStorage['endMinute'] = time.minute.toString();
  }

  void _startInstagram() {
    TimerSimulator.startInstagramTimer(instagramMinutes);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Instagram timer started: $instagramMinutes min')));
  }

  void _startWhatsApp() {
    TimerSimulator.startWhatsAppTimer(whatsappMinutes);
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('WhatsApp timer started: $whatsappMinutes min')));
  }

  void _stopInstagram() {
    TimerSimulator.stopInstagramTimer();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('Instagram timer stopped')));
  }

  void _stopWhatsApp() {
    TimerSimulator.stopWhatsAppTimer();
    ScaffoldMessenger.of(context)
        .showSnackBar(const SnackBar(content: Text('WhatsApp timer stopped')));
  }

  void _updateInstagramDisplay(int secondsLeft) {
    if (mounted) setState(() {});
  }

  void _updateWhatsAppDisplay(int secondsLeft) {
    if (mounted) setState(() {});
  }

  String _formatTime(int seconds) {
    int hours = seconds ~/ 3600;
    int minutes = (seconds % 3600) ~/ 60;
    int secs = seconds % 60;
    return '${hours.toString().padLeft(2, '0')}:${minutes.toString().padLeft(2, '0')}:${secs.toString().padLeft(2, '0')}';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Timer & Schedule Settings')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('Instagram Timer',
                        style: TextStyle(fontSize: 18)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        DropdownButton<int>(
                          value: instagramMinutes,
                          items: [30, 60, 90, 120]
                              .map((m) => DropdownMenuItem(
                                  value: m, child: Text('$m min')))
                              .toList(),
                          onChanged: (v) => _saveInstagramMinutes(v!),
                        ),
                        if (TimerSimulator.isInstagramRunning)
                          ElevatedButton(
                              onPressed: _stopInstagram,
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red),
                              child: const Text('Stop'))
                        else
                          ElevatedButton(
                              onPressed: _startInstagram,
                              child: const Text('Start')),
                      ],
                    ),
                    if (TimerSimulator.isInstagramRunning)
                      Text(
                          'Remaining: ${_formatTime(TimerSimulator.instagramSecondsLeft)}',
                          style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    const Text('WhatsApp Timer',
                        style: TextStyle(fontSize: 18)),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        DropdownButton<int>(
                          value: whatsappMinutes,
                          items: [30, 60, 90, 120]
                              .map((m) => DropdownMenuItem(
                                  value: m, child: Text('$m min')))
                              .toList(),
                          onChanged: (v) => _saveWhatsAppMinutes(v!),
                        ),
                        if (TimerSimulator.isWhatsAppRunning)
                          ElevatedButton(
                              onPressed: _stopWhatsApp,
                              style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.red),
                              child: const Text('Stop'))
                        else
                          ElevatedButton(
                              onPressed: _startWhatsApp,
                              child: const Text('Start')),
                      ],
                    ),
                    if (TimerSimulator.isWhatsAppRunning)
                      Text(
                          'Remaining: ${_formatTime(TimerSimulator.whatsAppSecondsLeft)}',
                          style: const TextStyle(fontSize: 16)),
                  ],
                ),
              ),
            ),
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  children: [
                    SwitchListTile(
                      title: const Text('Enable Daily Schedule'),
                      subtitle: const Text(
                          'App will auto-start/stop based on schedule'),
                      value: scheduleEnabled,
                      onChanged: _saveSchedule,
                    ),
                    const SizedBox(height: 10),
                    ListTile(
                      leading: const Icon(Icons.access_time),
                      title: const Text('Start Time'),
                      trailing: Text(startTime.format(context)),
                      onTap: () async {
                        final newTime = await showTimePicker(
                            context: context, initialTime: startTime);
                        if (newTime != null) _saveStartTime(newTime);
                      },
                    ),
                    ListTile(
                      leading: const Icon(Icons.access_time),
                      title: const Text('End Time'),
                      trailing: Text(endTime.format(context)),
                      onTap: () async {
                        final newTime = await showTimePicker(
                            context: context, initialTime: endTime);
                        if (newTime != null) _saveEndTime(newTime);
                      },
                    ),
                  ],
                ),
              ),
            ),
            const Text(
              'Note: Timer simulation runs while app is open. On real device, background timers will work even when app is closed.',
              style: TextStyle(fontSize: 12, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}
