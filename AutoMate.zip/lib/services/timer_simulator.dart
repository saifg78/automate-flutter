import 'dart:async';
import 'dart:html' as html;

class TimerSimulator {
  static Timer? _instagramTimer;
  static Timer? _whatsAppTimer;
  static int _instagramSecondsLeft = 0;
  static int _whatsAppSecondsLeft = 0;
  static bool _instagramRunning = false;
  static bool _whatsAppRunning = false;

  static Function(int)? onInstagramTick;
  static Function(int)? onWhatsAppTick;
  static Function()? onInstagramComplete;
  static Function()? onWhatsAppComplete;

  static void loadSettings() {
    _instagramSecondsLeft =
        int.tryParse(html.window.localStorage['instagramTimerSec'] ?? '3600') ??
            3600; // default 1 hour
    _whatsAppSecondsLeft =
        int.tryParse(html.window.localStorage['whatsappTimerSec'] ?? '3600') ??
            3600;
    _instagramRunning =
        html.window.localStorage['instagramTimerRunning'] == 'true';
    _whatsAppRunning =
        html.window.localStorage['whatsappTimerRunning'] == 'true';

    if (_instagramRunning) _startInstagramTimer();
    if (_whatsAppRunning) _startWhatsAppTimer();
  }

  static void startInstagramTimer(int minutes) {
    _instagramSecondsLeft = minutes * 60;
    html.window.localStorage['instagramTimerSec'] =
        _instagramSecondsLeft.toString();
    html.window.localStorage['instagramTimerRunning'] = 'true';
    _instagramRunning = true;
    _startInstagramTimer();
  }

  static void startWhatsAppTimer(int minutes) {
    _whatsAppSecondsLeft = minutes * 60;
    html.window.localStorage['whatsappTimerSec'] =
        _whatsAppSecondsLeft.toString();
    html.window.localStorage['whatsappTimerRunning'] = 'true';
    _whatsAppRunning = true;
    _startWhatsAppTimer();
  }

  static void stopInstagramTimer() {
    _instagramTimer?.cancel();
    _instagramRunning = false;
    html.window.localStorage['instagramTimerRunning'] = 'false';
  }

  static void stopWhatsAppTimer() {
    _whatsAppTimer?.cancel();
    _whatsAppRunning = false;
    html.window.localStorage['whatsappTimerRunning'] = 'false';
  }

  static void _startInstagramTimer() {
    _instagramTimer?.cancel();
    _instagramTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_instagramSecondsLeft > 0) {
        _instagramSecondsLeft--;
        html.window.localStorage['instagramTimerSec'] =
            _instagramSecondsLeft.toString();
        onInstagramTick?.call(_instagramSecondsLeft);
        if (_instagramSecondsLeft == 0) {
          timer.cancel();
          _instagramRunning = false;
          html.window.localStorage['instagramTimerRunning'] = 'false';
          onInstagramComplete?.call();
        }
      } else {
        timer.cancel();
        _instagramRunning = false;
        html.window.localStorage['instagramTimerRunning'] = 'false';
      }
    });
  }

  static void _startWhatsAppTimer() {
    _whatsAppTimer?.cancel();
    _whatsAppTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (_whatsAppSecondsLeft > 0) {
        _whatsAppSecondsLeft--;
        html.window.localStorage['whatsappTimerSec'] =
            _whatsAppSecondsLeft.toString();
        onWhatsAppTick?.call(_whatsAppSecondsLeft);
        if (_whatsAppSecondsLeft == 0) {
          timer.cancel();
          _whatsAppRunning = false;
          html.window.localStorage['whatsappTimerRunning'] = 'false';
          onWhatsAppComplete?.call();
        }
      } else {
        timer.cancel();
        _whatsAppRunning = false;
        html.window.localStorage['whatsappTimerRunning'] = 'false';
      }
    });
  }

  static int get instagramSecondsLeft => _instagramSecondsLeft;
  static int get whatsAppSecondsLeft => _whatsAppSecondsLeft;
  static bool get isInstagramRunning => _instagramRunning;
  static bool get isWhatsAppRunning => _whatsAppRunning;
}
