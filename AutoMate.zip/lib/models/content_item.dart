class ContentItem {
  final String id;
  final String name;
  final String type; // 'image' or 'video'
  bool used;

  ContentItem({
    required this.id,
    required this.name,
    required this.type,
    this.used = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'type': type,
        'used': used,
      };

  factory ContentItem.fromJson(Map<String, dynamic> json) => ContentItem(
        id: json['id'],
        name: json['name'],
        type: json['type'],
        used: json['used'] ?? false,
      );
}
