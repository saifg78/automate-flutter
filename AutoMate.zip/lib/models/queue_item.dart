class QueueItem {
  final String id;
  final String fileName;
  final String type; // 'image' or 'video'
  final int orderIndex;
  bool posted;

  QueueItem({
    required this.id,
    required this.fileName,
    required this.type,
    required this.orderIndex,
    this.posted = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'fileName': fileName,
        'type': type,
        'orderIndex': orderIndex,
        'posted': posted,
      };

  factory QueueItem.fromJson(Map<String, dynamic> json) => QueueItem(
        id: json['id'],
        fileName: json['fileName'],
        type: json['type'],
        orderIndex: json['orderIndex'],
        posted: json['posted'] ?? false,
      );
}
